# Indian Chemical Sector: Financial Performance and Sub-sector Analysis
## FY2019 to FY2024 | 22 NSE-listed Companies

**Author:** Naitik Singhal  
**Institute:** IIT Kanpur, Department of Chemical Engineering  
**Year of Study:** 2nd Year B.Tech (2024-28)  
**Date:** June 2025  

**Tools used:** Python 3, pandas, numpy, scikit-learn, matplotlib, openpyxl  
**Data sources:** Company annual reports, Screener.in, ICICI Direct sector reports, NSE disclosures  

---

## 1. Background and Objective

India's chemical industry has received a lot of attention over the last five years, driven partly by the China+1 supply chain shift, partly by domestic demand growth, and partly by government initiatives like the PLI scheme. However, a lot of the coverage treats the sector as one block. The reality is that a specialty chemicals firm like Clean Science Technology and a commodity chlor-alkali producer like Gujarat Alkalies are in very different businesses financially, even though they both fall under "chemicals" in sector classifications.

This project was an attempt to look at this more carefully. I took 22 NSE-listed chemical companies across 4 sub-sectors, pulled their financial data from FY2019 to FY2024, and tried to answer a few specific questions:

1. How different are the profitability levels across specialty, agrochemical, commodity, and dye/pigment sub-sectors? And has that gap been stable over time?
2. Beyond sub-sector labels, are there structurally distinct financial archetypes within the sector? I used K-Means clustering to check this.
3. Which variables are most associated with profitability? Export intensity, R&D spending, capex levels, or revenue scale?

---

## 2. Data and Sample

The 22 companies were selected to have reasonable representation across sub-sectors and market caps. The sample includes large caps (SRF, Tata Chemicals), mid caps (Vinati Organics, Navin Fluorine), and smaller specialty names (Clean Science, Alkyl Amines).

| Sub-Sector | Count | Companies |
|---|---|---|
| Specialty Chemicals | 14 | PI Industries, Aarti Industries, Deepak Nitrite, Vinati Organics, Navin Fluorine, SRF, Clean Science, Fine Organic, Alkyl Amines, Galaxy Surfactants, Atul, Laxmi Organic, NOCIL, BASF India |
| Agrochemicals | 4 | PI Industries, Rallis India, Bayer CropScience, Dhanuka Agritech |
| Commodity Chemicals | 4 | GHCL, Tata Chemicals, Gujarat Alkalies, PCBL |
| Dye and Pigment | 1 | Sudarshan Chemical |

For each company I collected revenue (INR Cr), EBITDA margins, PAT margins, ROE, export revenue as a percentage of total revenue, R&D spend as a percentage of revenue, and capex intensity (3-year average).

---

## 3. Methodology

**Feature engineering:**
- 5-year revenue CAGR (FY2019 to FY2024)
- Average EBITDA, PAT, and ROE across all 6 years
- EBITDA change from FY2019 to FY2024

**K-Means Clustering:**
Input features: Revenue CAGR, average EBITDA, average PAT, average ROE, export percentage, R&D percentage, capex percentage.

All features were standardized (Z-score) before clustering to prevent scale bias. Optimal k was determined using the elbow method (inertia vs k for k=2 through 7). The elbow was clear at k=4.

PCA with 2 components was used to create a 2D visualization of the clusters. The first two PCs explain roughly 58% of total variance.

**Composite Score:**
To rank companies overall, I built a weighted composite:

```
Score = 0.40 * EBITDA_norm + 0.30 * ROE_norm + 0.20 * RevCAGR_norm + 0.10 * RnD_norm
```

Each metric was normalized to 0-100 before weighting.

---

## 4. Findings

### 4.1 The margin gap between specialty and commodity is large and persistent

The specialty companies in the sample averaged 24.8% EBITDA margins over the 6-year period. Commodity companies averaged 11.5%. That is a 13.3 percentage point difference.

More interesting is that this gap has been stable. Even in FY2023 when specialty margins came down due to raw material cost spikes and China reopening, the spread stayed above 12 ppt.

The two biggest outliers on the upside are Clean Science Technology (avg EBITDA ~38.8%) and Vinati Organics (~34.8%). Both share a structural feature: they supply specific chemical molecules where they are one of very few global producers. That gives them pricing power that commodity producers simply do not have.

See: Plot 01 - EBITDA Margin Trends

### 4.2 The China+1 effect was real, but some of it has reversed

From FY2021 to FY2022, average specialty EBITDA margins went up by roughly 4 percentage points. This period coincides with the global shift in chemical procurement away from Chinese suppliers. Companies like PI Industries, Navin Fluorine, and SRF saw order books fill up and pricing improve.

By FY2023 and FY2024, some of this had reversed. Chinese exports came back at competitive prices, global agrochemical demand fell as inventory got worked off after the COVID restocking, and input cost inflation (energy, logistics) compressed margins for firms dependent on imported feedstocks.

This suggests the China+1 narrative is directionally correct as a structural trend, but a significant portion was pulled forward into FY2021-22 valuations and has since normalized.

### 4.3 Export orientation and profitability move together

Plotting export intensity (export revenue as % of total) against average EBITDA margin gives a positive correlation (Pearson r = 0.48). Companies with more than 50% export share delivered average EBITDA margins about 6 percentage points higher than companies with under 20% export exposure.

The logic is fairly intuitive. Export-oriented chemical companies tend to supply more specialized products to regulated markets like European crop protection or US pharma APIs. Getting regulatory approval in those markets takes years and is itself a competitive moat. Once you are an approved supplier, switching costs for customers are high, which supports pricing.

See: Plot 07 - Export vs Profitability

### 4.4 K-Means identifies 4 distinct financial archetypes

The clustering analysis groups the 22 companies into 4 well-separated clusters:

**Cluster 1 - Premium Specialty:** Clean Science, Vinati Organics, Alkyl Amines. High margins (30%+), high ROE. These are companies with genuine molecule-level competitive advantage. Revenue growth is moderate because they operate in niche markets with limited addressable scale.

**Cluster 2 - Agro-Export Champions:** PI Industries, Navin Fluorine, SRF, Fine Organic. Strong growth (15-30% CAGR) combined with good margins (24-28% EBITDA). This is the most attractive combination financially. Capex is higher here as these companies are actively building capacity.

**Cluster 3 - Transitioning Mid-tier:** Aarti Industries, Atul, Galaxy Surfactants, Laxmi Organic. Average performance across most metrics. Not bad businesses, but not differentiated enough to command premium margins or deliver high growth simultaneously. Some of these, like Aarti, are in the middle of multi-year capex cycles that are depressing near-term margins.

**Cluster 4 - Commodity Players:** GHCL, Gujarat Alkalies, Tata Chemicals, PCBL. Thin margins (10-13%), moderate growth, lower ROE. These companies compete on cost and scale rather than product differentiation. Margins are cyclical and tend to track global commodity benchmarks.

The PCA 2D plot shows reasonable cluster separation. About 58% of variance is captured in two dimensions, which is decent for data with 7 input features.

See: Plot 03 - Clustering, Plot 04 - Boxplots

### 4.5 R&D spending has a moderate positive association with margins

The correlation between R&D intensity and average EBITDA margin is 0.41. This is directionally sensible. Companies that invest in proprietary chemistry tend to operate in less competitive, higher-margin niches. PI Industries spends 3.8% of revenue on R&D and has EBITDA margins in the mid-20s. GHCL spends 0.4% and operates at 11-13%.

That said, the relationship is not tight. Galaxy Surfactants maintains decent margins with very low R&D through process efficiency. BASF India has relatively higher R&D spend but lower margins because of its product mix and competition from the parent company's global operations.

See: Plot 06 - Correlation Matrix

### 4.6 Composite ranking

The top 10 by composite score (EBITDA 40%, ROE 30%, revenue CAGR 20%, R&D 10%):

| Rank | Company | Score | Sub-Sector |
|---|---|---|---|
| 1 | Clean Science | 82.4 | Specialty |
| 2 | PI Industries | 79.1 | Agrochemical |
| 3 | Vinati Organics | 76.8 | Specialty |
| 4 | Alkyl Amines | 71.2 | Specialty |
| 5 | Deepak Nitrite | 70.4 | Specialty |
| 6 | Galaxy Surfactants | 68.3 | Specialty |
| 7 | Navin Fluorine | 67.9 | Specialty |
| 8 | Fine Organic | 65.1 | Specialty |
| 9 | Dhanuka Agritech | 61.8 | Agrochemical |
| 10 | SRF Ltd | 60.4 | Specialty |

Specialty and agrochemical companies dominate the top 10. No commodity firm appears.

See: Plot 08 - Composite Ranking

---

## 5. What This Might Mean for Strategy

**For a company deciding where to compete:**
The data supports two viable paths for Indian chemical firms. First is deep specialization: invest in proprietary molecules, get regulatory approvals in export markets, and accept lower revenue scale in exchange for high and durable margins (the Clean Science and Vinati path). Second is scale plus downstream integration: operate at commodity scale but move down the value chain into specialty derivatives over time (what PCBL is attempting with specialty carbon black for high-performance tyres).

The middle ground, running mid-scale commodity chemicals without a clear differentiation plan, is the most vulnerable position in the data. These are Cluster 3 and 4 companies, and their financial profiles reflect it.

**For policy:**
The PLI scheme and draft National Chemical Policy are pointed in the right direction in targeting specialty and green chemistry. The data shows specialty firms are generating global-quality returns (20-30%+ ROE) and building meaningful export revenue. A few things could help this compound faster: faster environmental clearances for chemical plant expansions (a known bottleneck), enhanced R&D deductions to incentivize proprietary chemistry, and chemical park development with shared utilities to reduce the fixed cost barrier for smaller specialty entrants.

---

## 6. Limitations

Some things to be upfront about with this analysis:

The financial figures are sourced from annual reports and Screener.in aggregated data. I have tried to be accurate but minor discrepancies with exact filings are possible. The directional findings, which rely on relative comparisons and trends, should hold even with small data errors.

The 22-company sample is not exhaustive. The NSE-listed chemical universe is around 80+ firms. The sample skews toward larger, well-followed companies, which means the commodity segment is likely underrepresented.

EBITDA margins are not perfectly comparable across companies because of differences in how exceptional items, ESOP charges, and depreciation are treated. The cross-company comparisons carry this caveat.

Cluster interpretation is subjective. The K-Means algorithm groups companies by mathematical distance in feature space. The labels I assigned ("Premium Specialty", etc.) are interpretive based on looking at the cluster centroids, not something the algorithm outputs.

This analysis covers only operational and financial metrics. I have not looked at valuation multiples, debt levels, working capital cycles, or promoter quality, all of which matter for a complete view.

---

## 7. Summary

The main finding is that Indian chemicals is not a homogeneous sector and treating it as one leads to poor analysis. Specialty chemicals companies have delivered structurally different financial performance compared to commodity peers across the entire FY2019-2024 period. The gap is 13+ ppt on EBITDA and has been stable through COVID, the China+1 wave, and the subsequent correction.

Export orientation (r = 0.48) and R&D intensity (r = 0.41) are the clearest predictors of profitability in the sample. K-Means clustering identifies 4 meaningful archetypes that cut across but also align with the traditional sub-sector labels.

The medium-term outlook for the sector depends a lot on which cluster you are looking at. Cluster 1 and 2 companies have structural advantages that are unlikely to erode quickly. Cluster 3 companies are at an inflection point, capex cycles need to start delivering margin improvement. Cluster 4 faces the most structural pressure from Chinese competition on commodity grades.

---

*All data is from public sources. Code and analysis are original. This is an independent study done as part of sector analysis practice.*
