# Indian Chemical Sector Financial Analysis (FY2019-FY2024)

A study of 22 NSE-listed chemical companies across FY2019 to FY2024, looking at sub-sector profitability differences, financial archetypes via clustering, and what drives margins.

**Author:** Naitik Singhal, IIT Kanpur (Chemical Engineering, 2nd Year)

---

## What the project does

India's chemical sector is often discussed as a single entity, but a specialty molecule supplier and a commodity chlor-alkali producer are very different businesses. This project tries to quantify how different, using six years of financial data.

Three main questions:
1. How wide is the EBITDA margin gap between specialty, agrochemical, and commodity sub-sectors? How has it moved through COVID and the China+1 period?
2. Are there structurally distinct firm archetypes within the sector beyond sub-sector labels? (answered via K-Means)
3. What financial metrics are most correlated with profitability?

---

## Key numbers

- Specialty vs commodity EBITDA spread: **13.3 ppt** (24.8% vs 11.5%, averaged FY2019-2024)
- Highest 5-year revenue CAGR: **Deepak Nitrite at 31.9%**
- Export intensity vs EBITDA correlation: **r = 0.48**
- R&D intensity vs EBITDA correlation: **r = 0.41**
- Clusters found: **4 distinct groups** via K-Means (k=4 by elbow method)

---

## Folder structure

```
indian-chemical-sector-analysis/
├── data/
│   ├── indian_chemicals_data.py     master dataset, 22 companies FY2019-2024
│   ├── master_data.csv              exported CSV version
│   └── cluster_assignments.csv      K-Means output
│
├── src/
│   ├── analysis.py                  generates all 10 plots
│   └── generate_excel.py            builds the Excel workbook
│
├── plots/
│   ├── 01_ebitda_margin_trend.png
│   ├── 02_growth_profitability_matrix.png
│   ├── 03_kmeans_clustering.png
│   ├── 04_margin_boxplot.png
│   ├── 05_revenue_waterfall.png
│   ├── 06_correlation_heatmap.png
│   ├── 07_export_vs_margin.png
│   ├── 08_composite_ranking.png
│   ├── 09_rnd_vs_capex.png
│   └── 10_ebitda_heatmap.png
│
├── reports/
│   ├── report.md                              full written analysis
│   └── Indian_Chemical_Sector_Analysis.xlsx   Excel workbook
│
├── requirements.txt
└── README.md
```

---

## Charts produced

| File | What it shows |
|---|---|
| 01_ebitda_margin_trend | Average EBITDA margins by sub-sector across FY2019-FY2024 |
| 02_growth_profitability_matrix | 2x2 scatter: revenue CAGR vs avg EBITDA, bubble = FY2024 revenue |
| 03_kmeans_clustering | Elbow method + PCA 2D scatter of 4 clusters |
| 04_margin_boxplot | EBITDA and ROE distributions by sub-sector |
| 05_revenue_waterfall | Sub-sector aggregate revenue FY2019 vs FY2024 |
| 06_correlation_heatmap | Pearson correlations across 7 financial metrics |
| 07_export_vs_margin | Export intensity vs average EBITDA margin |
| 08_composite_ranking | Top 10 companies by weighted composite score |
| 09_rnd_vs_capex | R&D vs capex intensity, bubble = profitability |
| 10_ebitda_heatmap | EBITDA margins for all companies across all years |

---

## How to run

```bash
git clone https://github.com/YOUR_USERNAME/indian-chemical-sector-analysis.git
cd indian-chemical-sector-analysis

pip install -r requirements.txt

# generate all plots
python src/analysis.py

# generate Excel workbook
python src/generate_excel.py
```

---

## Methodology notes

**Dataset:** Revenue, EBITDA margins, PAT margins, ROE, export %, R&D %, and capex % for 22 companies across FY2019-2024. Collected from annual reports and Screener.in.

**Clustering:** K-Means with k=4. Features Z-score normalized before fitting. Elbow method used for k selection. PCA (2 components, ~58% variance explained) for visualization.

**Composite score:** Normalized weighted average across EBITDA margin (40%), ROE (30%), revenue CAGR (20%), R&D intensity (10%).

**Limitations:** Data approximated from public sources; sample skews toward larger listed firms; no valuation data included; EBITDA not perfectly comparable across companies due to accounting differences.

---

## Excel workbook sheets

- **Master Data** - all companies, all metrics, sorted by composite score
- **Sub-sector Summary** - aggregated by sub-sector with CAGR calculations
- **EBITDA Trends** - year-by-year EBITDA margins with conditional formatting
- **Revenue Data** - revenue history with growth colour coding
- **Cluster Results** - K-Means cluster assignments with profiles

---

*Data from public disclosures. Independent project for learning purposes.*
